<?php
  require('./libreria.php'); //Libreria requerida para el funcionamiento.
  $getData = leerDatos(); //Lee los datos
  obtnciudad($getData) //Ejecuta y obtiene la ciudad
?>
