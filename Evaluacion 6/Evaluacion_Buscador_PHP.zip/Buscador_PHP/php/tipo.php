<?php
  require('./libreria.php');
  $getData = leerDatos(); //Leer la informacion del archivo json.
  obtnTipo($getData)
?>
